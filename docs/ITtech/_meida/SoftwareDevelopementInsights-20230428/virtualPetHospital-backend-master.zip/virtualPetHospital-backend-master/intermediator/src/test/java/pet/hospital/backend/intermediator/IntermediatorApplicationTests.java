package pet.hospital.backend.intermediator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntermediatorApplicationTests {

    @Test
    void contextLoads() {}
}
