<!-- 3D 医院地图 -->

<template>
  <div class="overview-wrapper">
    <mapView />
  </div>
</template>

<script setup>
import mapView from "@/components/mapView.vue";
</script>
