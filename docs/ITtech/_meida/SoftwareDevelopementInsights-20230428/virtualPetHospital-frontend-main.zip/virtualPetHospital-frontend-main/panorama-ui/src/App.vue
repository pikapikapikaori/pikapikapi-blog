<template>
  <div id="app">
    <Main></Main>
  </div>
</template>

<script>
import Main from "./view/Main.vue";

export default {
  name: "app",
  components: {
    Main,
  },
};
</script>
