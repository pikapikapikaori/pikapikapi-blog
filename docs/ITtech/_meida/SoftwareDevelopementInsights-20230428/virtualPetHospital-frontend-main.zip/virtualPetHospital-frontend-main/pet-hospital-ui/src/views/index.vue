<!-- 首页 -->

<template>
  <div class="app-container">
    <Welcome />
  </div>
</template>

<script setup>
import Welcome from "./Welcome/index.vue";
</script>
