DELETE
FROM
    USER
WHERE
    user_id = 1;

DELETE
FROM
    USER
WHERE
    user_name = 'admin@admin.com';

INSERT
    INTO
        USER
    VALUES(
        1,
        'admin@admin.com',
        'admin',
        1
    );
